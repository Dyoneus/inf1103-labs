from product import Product
from order_line import OrderLine

class Order:
    def __init__(self, order_id: str) -> None:
        self.__order_id: str = order_id
        self.__order_lines: list[OrderLine] = []

    def get_order_id(self) -> str:
        return self.__order_id

    def add_order_line(self, product: Product, quantity: int) -> None:
        if quantity <= 0:
            print("Quantity must be greater than zero.")
            return

        order_line = OrderLine(product, quantity)
        self.__order_lines.append(order_line)

    def calculate_total(self) -> float:
        total = 0.0

        for order_line in self.__order_lines:
            total += order_line.calculate_subtotal()

        return total

    def get_order_lines(self) -> list[OrderLine]:
        return self.__order_lines.copy()

    def remove_order_line(self, line_number: int) -> bool:
        if line_number < 1 or line_number > len(self.__order_lines):
            return False

        # line number start from 1
        del self.__order_lines[line_number - 1]
        return True

    def display_order(self) -> None:
        print("\nOrder ID:", self.__order_id)

        line_number = 1

        for order_line in self.__order_lines:
            print("\nLine:", line_number)
            order_line.display_information()
            line_number += 1

        print("\nOrder Total:", self.calculate_total())